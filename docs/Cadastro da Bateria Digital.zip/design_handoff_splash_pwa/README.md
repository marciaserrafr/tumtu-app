# Handoff: Tela de carregamento (splash) do PWA TumTu — iOS

## Overview

O TumTu é um PWA de gestão de baterias de escola de samba (cadastro de ritmistas, carteirinha digital, aprovação por Mestre/Diretor). Quando instalado na tela de início do iPhone, o iOS desenha sua própria tela no instante entre o toque no ícone e o carregamento do app — e essa tela **vaza uma cor branca/clara nas bordas** (topo, junto ao notch/ilha dinâmica, ou nas laterais próximas aos cantos arredondados). O vazamento é inconsistente: varia a cada abertura, mesmo com splash screens corretas e configuração de safe-area. Não é controlável 100% via código.

A solução aqui **não tenta esconder o vazamento** — ela o torna irrelevante. A tela de carregamento usa uma **moldura clara intencional** (passe-partout `#f7f6fb`, o cinza bem claro `--cor-fundo-claro` que o app já usa) em volta de um cartão escuro. O vazamento branco do iOS cai sobre esse cinza quase branco, onde é praticamente invisível. Como bônus, a moldura evoca carteirinha/passaporte — exatamente o que o usuário vai buscar dentro do app.

O cartão escuro começa **exatamente na linha onde começa o header do app**, para que a transição do splash para o login/dashboard não pisque. Esse alinhamento é o requisito mais importante da implementação — detalhado abaixo.

No miolo do cartão, uma animação traduz o nome do app em movimento: os dois círculos do símbolo TumTu batem no ritmo do surdo — **TUM** (círculo grande dourado, batida forte, solta uma onda de ar) e **tu** (círculo pequeno terracota, resposta mais fraca, 150ms depois).

## About the Design Files

Os arquivos deste pacote são **referências de design criadas em HTML** — protótipos que mostram a aparência e o comportamento pretendidos, **não código de produção para copiar direto**.

A tarefa é **recriar esses designs no ambiente já existente do codebase do TumTu** (React, Vue, SvelteKit, etc.), usando seus padrões e bibliotecas estabelecidos. Se ainda não existir um ambiente definido para essa tela, escolha o mais apropriado ao projeto e implemente lá.

Atenção especial no caso desta tela: por ser a **primeira coisa renderizada** ao abrir o PWA, ela deve ser o mais leve possível — idealmente CSS puro inline no `index.html` (ou equivalente), sem depender do bundle JS ter carregado. Se a splash só aparecer depois do React montar, ela perde o propósito.

## Fidelity

**High-fidelity (hifi).** Cores, tipografia, espaçamentos, tamanhos e timings de animação são finais. Recrie com fidelidade de pixel usando as bibliotecas e padrões do codebase.

## Screens / Views

### Splash / Loading — "Passaporte" (direção aprovada: `1a`)

**Purpose:** primeira tela visível ao abrir o PWA. Cobre o intervalo entre o launch do iOS e o app estar pronto, absorvendo o vazamento de borda do iOS e apresentando a identidade da marca.

**Layout (referência: iPhone 390 × 844 pt):**

- **Container externo (a moldura):**
  - `width: 100%` / `height: 100%` — deve ocupar **toda a viewport**, incluindo as safe areas (`viewport-fit=cover`)
  - `background: #f7f6fb` — token `--cor-fundo-claro` já existente no app (cinza bem claro, quase branco). **Não usar creme/bege:** foi testado e dá problema.
  - `padding: env(safe-area-inset-top) 20px 20px 20px` — no **topo** a cor clara ocupa exatamente a faixa do status bar (para o escuro começar na linha do header); nas **laterais e embaixo** a moldura de `20px` é mantida
  - `box-sizing: border-box`
  - `display: flex`
  - Na referência HTML o padding-top é `54px` (altura aproximada do status bar do iPhone 14/15) e há `border-radius: 44px` — ambos **existem apenas para simular o iPhone no mockup**. Na implementação real use `env(safe-area-inset-top)` no topo e **nenhum border-radius no container externo**; o próprio dispositivo faz o arredondamento.

- **Cartão interno (escuro):**
  - `flex: 1`
  - `background: #12101a`
  - `border-radius: 30px`
  - `display: flex; flex-direction: column; align-items: center; justify-content: center;`
  - `gap: 52px`
  - `position: relative; overflow: hidden;`

  ### ⚠️ Requisito crítico: alinhamento com o header do app

  A borda superior do cartão escuro **deve cair exatamente na mesma linha** onde começa o header verde do app (logo abaixo do status bar). Se o splash tiver qualquer offset extra no topo, a tela **pisca** na transição para o login/dashboard, porque o escuro "salta" alguns pixels.

  Por isso **o topo é o único lado sem os 20px de moldura**: lá a cor clara ocupa apenas a faixa do status bar. As laterais e a base mantêm os 20px, preservando o efeito de passe-partout e a proteção contra vazamento lateral.

  Na prática: o padding-top do splash tem que ser **o mesmo valor** de `env(safe-area-inset-top)` (ou o mesmo espaçador) que o header do app usa. Se o header resolve a safe area por outra técnica (spacer fixo, wrapper com padding, `100dvh`), **replique a técnica dele** em vez de reimplementar com `env()` — é o único jeito de garantir que as duas linhas coincidam em todos os modelos de iPhone.

**Components (de cima para baixo, centralizados):**

1. **Símbolo animado (dois círculos)**
   - Wrapper: `position: relative; width: 170px; height: 130px; display: flex; align-items: center; justify-content: center;`
   - **Onda de ar** (anel que se expande na batida forte):
     - `position: absolute; left: 6px; top: 16px; width: 88px; height: 88px;`
     - `border-radius: 50%; border: 1px solid #D4AF37;`
     - `animation: onda 1.05s cubic-bezier(.2,.6,.3,1) infinite;`
   - **Círculo grande — "TUM"** (preenchido, dourado):
     - `position: absolute; left: 6px; top: 16px; width: 88px; height: 88px;`
     - `border-radius: 50%; background: #D4AF37;`
     - `animation: tum 1.05s cubic-bezier(.16,.8,.3,1) infinite;`
   - **Círculo pequeno — "tu"** (vazado, terracota, à direita e abaixo):
     - `position: absolute; left: 106px; top: 78px; width: 38px; height: 38px;`
     - `border-radius: 50%; border: 2px solid #7c2d12;` — mesma espessura do símbolo oficial (`.simbolo-marca .small`)
     - `animation: tu 1.05s cubic-bezier(.16,.8,.3,1) infinite; animation-delay: .15s;`
   - ⚠️ A espessura de `2px` do contorno **confere com o símbolo oficial** (`.simbolo-marca .small`, usado no login). Já os diâmetros (88px / 38px) e a distância entre os centros são uma aproximação em escala maior — se houver especificação oficial de proporção, ou um SVG do símbolo, use-o e mantenha apenas os timings de animação daqui.

2. **Wordmark "TumTu"**
   - `display: flex; align-items: baseline; font-size: 34px; font-weight: 800; letter-spacing: 0.5px;`
   - Letra por letra: `T` `#D4AF37` → `u` `#ffffff` → `m` `#ffffff` → `T` `#D4AF37` → `u` `#ffffff`
   - Sob a letra **m** apenas: linha `position: absolute; left: 0; right: 0; bottom: -6px; height: 2px; background: #7c2d12;` (o `m` precisa de `position: relative`)
   - Não animado.

3. **Barra de compasso (indicador de carregamento indeterminado)**
   - Trilha: `width: 56px; height: 2px; background: rgba(212,175,55,.18); border-radius: 2px; overflow: hidden;`
   - Preenchimento: `width: 33%; height: 100%; background: #D4AF37;`
   - `animation: compasso 1.05s linear infinite;` — mesmo ciclo da batida, para o pulso visual e o indicador ficarem sincronizados.

4. **Legenda de status**
   - `position: absolute; bottom: 40px;`
   - Texto: **"Afinando a bateria"**
   - `color: #6f6980; font-size: 13px; font-weight: 600; letter-spacing: 1.5px; text-transform: uppercase;`
   - `animation: respira 2.1s ease-in-out infinite;`

### Direções alternativas (não aprovadas, documentadas para contexto)

- **`1b` — Inversão:** tela inteira creme `#efe9dc`, símbolo e wordmark em tinta escura (dourado escurecido para `#c79c23` / `#a8862a` por contraste). Risco de vazamento **zero**, porque não existe borda escura. Descartada porque a abertura não fica escura como o resto do app.
- **`1c` — Couro do surdo:** moldura dourada `#D4AF37` de 26px + cartão escuro com `border-radius: 24px`; círculo grande em creme, pequeno vazado em dourado (`border: 2px`). Mais memorável, mas **não resolve o problema**: um vazamento branco ainda aparece como mancha clara sobre o dourado. Descartada pelo usuário por esse motivo.

Ambas estão implementadas no HTML de referência, caso queiram ser revisitadas.

## Interactions & Behavior

- **Sem interações.** A tela é puramente passiva — nenhum toque, nenhum botão.
- **Ciclo de vida:** aparece imediatamente no load e é removida quando o app está pronto (dados de sessão/carteirinha carregados). Recomenda-se um **fade-out de ~250ms** na saída em vez de remoção abrupta, e um **tempo mínimo de exibição de ~600ms** para a batida completar pelo menos meio ciclo — caso contrário, em conexões rápidas, a animação apenas pisca.
- **Animações** (todas em loop infinito, sem interação):

```css
/* TUM — batida forte do surdo */
@keyframes tum {
  0%   { transform: scale(1); }
  7%   { transform: scale(1.15); }
  30%  { transform: scale(1); }
  100% { transform: scale(1); }
}

/* tu — resposta, mais fraca e atrasada (animation-delay: .15s) */
@keyframes tu {
  0%   { transform: scale(1);    opacity: .75; }
  7%   { transform: scale(1.09); opacity: 1; }
  34%  { transform: scale(1);    opacity: .75; }
  100% { transform: scale(1);    opacity: .75; }
}

/* onda de ar que sai do couro na batida forte */
@keyframes onda {
  0%   { transform: scale(.75); opacity: .5; }
  70%  { transform: scale(2.1); opacity: 0; }
  100% { transform: scale(2.1); opacity: 0; }
}

/* barra de compasso — indicador indeterminado */
@keyframes compasso {
  0%   { transform: translateX(-100%); }
  100% { transform: translateX(300%); }
}

/* legenda de status */
@keyframes respira {
  0%, 100% { opacity: .45; }
  50%      { opacity: .9; }
}
```

  - **Ciclo base: 1.05s** — tempo de surdo de marcação (~114 bpm). Todos os elementos compartilham esse ciclo; é o que faz a tela parecer batida e não animação genérica.
  - **Easings:** `cubic-bezier(.16,.8,.3,1)` nos círculos (ataque rápido, decaimento suave — comportamento de pele de tambor); `cubic-bezier(.2,.6,.3,1)` na onda; `linear` na barra; `ease-in-out` na legenda.
  - Animar apenas `transform` e `opacity` (composited). Não animar `width`/`height`/`box-shadow`.

- **Acessibilidade:** respeitar `@media (prefers-reduced-motion: reduce)` — congelar os círculos no estado de repouso (`scale(1)`), esconder a onda e substituir a barra de compasso por um estado estático ou fade suave.
- **Responsivo:** o layout é centralizado e proporcional; funciona de iPhone SE a Pro Max sem breakpoints. A moldura sempre acompanha a viewport.

## State Management

Estado mínimo, um único booleano:

| Estado | Tipo | Transição |
|---|---|---|
| `isAppReady` | boolean | `false` no load → `true` quando sessão + dados essenciais resolvem |
| `minTimeElapsed` | boolean | `false` → `true` após ~600ms (timer no mount) |

A splash é desmontada quando `isAppReady && minTimeElapsed`. Sem data fetching próprio — apenas observa o boot do app.

## Design Tokens

**Cores**

| Token | Hex | Uso |
|---|---|---|
| Fundo escuro | `#12101a` | cartão interno |
| Claro (moldura) | `#f7f6fb` | moldura + faixa do status bar — token `--cor-fundo-claro`; absorve o vazamento do iOS |
| Dourado | `#D4AF37` | círculo grande, T's do wordmark, barra de compasso, onda |
| Terracota | `#7c2d12` | círculo pequeno (contorno), linha sob o "m" |
| Branco | `#ffffff` | letras `u`, `m`, `u` do wordmark |
| Cinza-roxo | `#6f6980` | legenda de status |
| Trilha da barra | `rgba(212,175,55,.18)` | fundo do indicador |
| Dourado escuro | `#c79c23` / `#a8862a` | apenas na variante `1b`, sobre fundo claro |

**Espaçamento:** `env(safe-area-inset-top)` no topo e `20px` nas laterais/base (moldura), `52px` (gap vertical do cartão), `16px` (gap wordmark↔barra), `40px` (offset inferior da legenda)

**Tipografia:** Plus Jakarta Sans — wordmark `34px / 800 / letter-spacing 0.5px`; legenda `13px / 600 / letter-spacing 1.5px / uppercase`

**Border radius:** `30px` (cartão interno), `50%` (círculos), `2px` (barra)

**Sombras:** nenhuma na tela real. O `box-shadow: 0 24px 60px rgba(0,0,0,.5)` do HTML é só apresentação do mockup — descarte.

## Assets

Nenhum arquivo de imagem. Tudo é CSS puro (círculos por `border-radius`) e texto.

- **Fonte:** Plus Jakarta Sans, pesos 400–800 (Google Fonts na referência). Em produção, **auto-hospede e faça preload** — a splash é a primeira tela e não deve depender de fetch de fonte externa. Alternativa: aceitar `font-display: swap` com uma system font de fallback, já que o wordmark é curto.
- **Símbolo da marca:** desenhado em CSS por aproximação. Se houver SVG oficial, prefira-o (ver ressalva na seção do símbolo).

## Files

| Arquivo | Conteúdo |
|---|---|
| `Splash PWA - TumTu.dc.html` | As três direções (`1a`, `1b`, `1c`) lado a lado, animadas, em frames de 390×844. A aprovada é a **`1a` — Passaporte**. Os `@keyframes` estão no `<style>` do topo. |
| `1a-passaporte.png` | Screenshot da direção aprovada (780×1688 @2x), frame congelado da animação. |
| `1b-inversao.png` | Screenshot da alternativa `1b` (não aprovada). |
| `1c-couro-do-surdo.png` | Screenshot da alternativa `1c` (não aprovada). |

Os PNGs são frames estáticos — para ver a batida, abra o HTML no navegador.

Abra o HTML direto no navegador para ver as animações rodando.
